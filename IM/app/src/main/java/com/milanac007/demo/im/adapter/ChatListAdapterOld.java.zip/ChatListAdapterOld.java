
package com.milanac007.demo.im.adapter;

import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Vibrator;
import android.text.Editable;
import android.text.Html;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ClickableSpan;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.alibaba.fastjson.JSONObject;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.load.model.LazyHeaders;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.example.milanac007.pickerandpreviewphoto.CacheManager;
import com.milanac007.demo.im.App;
import com.milanac007.demo.im.R;
import com.milanac007.demo.im.db.config.DBConstant;
import com.milanac007.demo.im.db.config.MessageConstant;
import com.milanac007.demo.im.db.entity.GroupMemberEntity;
import com.milanac007.demo.im.db.entity.MessageEntity;
import com.milanac007.demo.im.db.entity.UserEntity;
import com.milanac007.demo.im.db.entity.msg.AudioMessage;
import com.milanac007.demo.im.db.entity.msg.ImageMessage;
import com.milanac007.demo.im.db.entity.msg.TextMessage;
import com.milanac007.demo.im.db.entity.msg.VideoMessage;
import com.milanac007.demo.im.db.helper.EntityChangeEngine;
import com.milanac007.demo.im.fragment.BaseFragment;
import com.milanac007.demo.im.fragment.ChatFragment;
import com.milanac007.demo.im.logger.Logger;
import com.milanac007.demo.im.manager.FaceManager;
import com.milanac007.demo.im.net.CustomFileDownload;
import com.milanac007.demo.im.service.IMService;
import com.milanac007.demo.im.ui.CircleImageView;
import com.milanac007.demo.im.ui.CustomConfirmDialog;
import com.milanac007.demo.im.ui.CustomRoundProgressBar;
import com.milanac007.demo.im.ui.LinkMovementClickMethod;
import com.milanac007.demo.im.utils.CommonFunction;
import com.milanac007.demo.im.utils.Preferences;
import com.milanac007.demo.im.utils.Utils;
//import com.mogujie.tt.DB.DBInterface;


import org.xml.sax.XMLReader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.fragment.app.Fragment;

public class ChatListAdapterOld extends SelectBaseAdapter{
    public static final String TAG = "ChatListAdapter";
    private Context context;
    private BaseFragment mCurrentFragment;
    private LayoutInflater inflater;
    private ArrayList<MessageEntity> mMsgList;
    private MediaPlayer mediaPlayer = null;
    private AnimationDrawable animationDrawable = null;
    Animation loadingAnim;
    private List<MessageEntity> showTimeMsgIdList = new ArrayList<>();//需要显示时间ui的msgId集合

    /**震动服务*/
    private Vibrator vib = (Vibrator) App.getInstance().getSystemService(Service.VIBRATOR_SERVICE);

    private IMService imService;
    private UserEntity loginUser;
    private String sessionKey;
    private int sessionType;
    private int sessionId;

    private int mMode = R.id.NORMAL_MODE;
    public void setMode(int mode){
        mMode = mode;
        notifyDataSetChanged();
    }
    public int getMode(){
        return mMode;
    }

    public  ChatListAdapterOld(BaseFragment fragment, IMService imService, UserEntity loginUser, String sessionKey, List<MessageEntity> msgList) {
        this.imService = imService;
        this.loginUser = loginUser;
        this.context = fragment.getActivity();
        mCurrentFragment = fragment;
        inflater = LayoutInflater.from(this.context);
        loadingAnim = AnimationUtils.loadAnimation(context, R.anim.roatate_anim);

        this.sessionKey = sessionKey;
        String[] sessionInfo = EntityChangeEngine.spiltSessionKey(sessionKey);
        sessionType = Integer.parseInt(sessionInfo[0]);
        sessionId = Integer.parseInt(sessionInfo[1]);

        if(mMsgList == null)
            mMsgList = new ArrayList<>();
        mMsgList.addAll(msgList);
    }

    public  ChatListAdapterOld(BaseFragment fragment, IMService imService, UserEntity loginUser, String sessionKey, List<MessageEntity> msgList, int mode){
        this(fragment, imService, loginUser, sessionKey, msgList);
        mMode = mode;
    }

    public List<MessageEntity> getAllData(){
        return mMsgList;
    }

    @Override
    public int getCount() {
        return mMsgList == null ? 0 : mMsgList.size();
    }

    public void clearData(){
        if(mMsgList != null && !mMsgList.isEmpty())
            mMsgList.clear();
    }

    @Override
    public Object getItem(int position) {
        return mMsgList == null ? null : mMsgList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public long getLastCreatedTime(){

        if(mMsgList == null || mMsgList.isEmpty())
            return  0;

        long time = mMsgList.get(0).getCreated();
        //TODO 是否需要排序
        return time;
    }

    public void updateData(){

        Collections.sort(mMsgList, new ChatListAdapter.MessageTimeComparator());
        showTimeMsgIdList.clear();

        int preTime = 0;
        int nextTime = 0;
        for (MessageEntity msg : mMsgList) {
            nextTime = (int)(msg.getCreated()/1000);

            if(nextTime - preTime > 60){ //大于一分钟
                showTimeMsgIdList.add(msg);
            }

            preTime = nextTime;
        }

        notifyDataSetChanged();
    }

    /**
     * 下拉载入历史消息,从最上面开始添加
     */
    public void loadHistoryList(final List<MessageEntity> historyList) {

        if (null == historyList || historyList.size() <= 0) {
            return;
        }

        // 如果是历史消息，从头开始加
        mMsgList.addAll(0, historyList);
        updateData();
    }

    public void addItem(MessageEntity msg) {

        if(!mMsgList.contains(msg)) {
            int preTime = mMsgList.size()> 0 ? (int)(mMsgList.get(mMsgList.size()-1).getCreated()/1000) : 0;
            mMsgList.add(msg);
            int nextTime = (int)(msg.getCreated()/1000);
            if(nextTime - preTime > 60){ //大于一分钟
                showTimeMsgIdList.add(msg);
            }
        }
        notifyDataSetChanged();
    }

    public void updateItemState(MessageEntity msg){
        if(!sessionKey.equals(msg.getSessionKey())) //非该会话的消息
            return;

        long dbId = msg.getId();
        int msgId = msg.getMsgId();
        int len = mMsgList.size();
        for (int index = len - 1; index >= 0; index--) {
            MessageEntity entity = mMsgList.get(index);
            if(entity.getId() == null){
                Logger.getLogger().e("%s", "msg updateItemState: entity.getId() == null");
                continue;
            }


            if (dbId == entity.getId()  && msgId == entity.getMsgId()) {
                mMsgList.set(index, msg);
                break;
            }
        }
        notifyDataSetChanged();
    }

    public void removeItem(MessageEntity msg) {
        if (mMsgList.contains(msg)) {
            mMsgList.remove(msg);
            showTimeMsgIdList.remove(msg);

            notifyDataSetChanged();
        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        final MessageEntity msg = (MessageEntity) getItem(position);
        int msgType = msg.getMsgType();

        switch (msgType){
            case DBConstant.MSG_TYPE_SINGLE_TEXT:
            case DBConstant.MSG_TYPE_GROUP_TEXT:
                return getTextMsgView((TextMessage)msg, convertView);
            case DBConstant.MSG_TYPE_SINGLE_IMG:
            case  DBConstant.MSG_TYPE_GROUP_IMG:
                return getImageMsgView((ImageMessage)msg, convertView);
            case DBConstant.MSG_TYPE_SINGLE_AUDIO:
            case  DBConstant.MSG_TYPE_GROUP_AUDIO:
                return getVoiceMsgView(position, (AudioMessage)msg, convertView);
            case DBConstant.MSG_TYPE_SINGLE_VEDIO:
            case  DBConstant.MSG_TYPE_GROUP_VEDIO:
                return  getVideoMsgView((VideoMessage)msg, convertView);
            case DBConstant.MSG_TYPE_SINGLE_SYSTEM_TEXT:
            case DBConstant.MSG_TYPE_GROUP_SYSTEM_TEXT:
            case DBConstant.MSG_TYPE_NEED_ADD_BUDDY_VERIFY_SYSTEM_TEXT:
                return getSystemMsgView((TextMessage)msg, convertView);
        }

        return convertView;
    }

    private void setSystemMsgData(final TextMessage msg, final SystemMsgViewHolder holder) {
        setMsgDateTime(msg, holder.send_msg_date);
        holder.system_msg_content.setText(msg.getContent());
        if(msg.getMsgType() == DBConstant.MSG_TYPE_NEED_ADD_BUDDY_VERIFY_SYSTEM_TEXT){
            setOnClickListener(msg, holder.system_msg_content);
        }
    }

    private void setOnClickListener(final TextMessage msg, TextView msgView){

        msgView.setMovementMethod(LinkMovementClickMethod.getInstance()); //设置可点击
        final String msgText = msg.getContent();
        final String sendVerifyMsgText = "发送好友验证";
        msgView.append(Html.fromHtml(sendVerifyMsgText, null, new Html.TagHandler() {
            @Override
            public void handleTag(boolean opening, String tag, Editable output, XMLReader xmlReader) {

                String str = output.toString();
                Pattern pattern = Pattern.compile(sendVerifyMsgText, Pattern.CASE_INSENSITIVE);
                Matcher matcher = pattern.matcher(str);

                while (matcher.find()) {
                    int start = matcher.start();
                    int end = matcher.end();
                    output.setSpan(new AddBuddyVerifyClickSpan(msg.getFromId()), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                }
            }
        }));
    }

    class AddBuddyVerifyClickSpan extends ClickableSpan{
        private int buddyid;

        AddBuddyVerifyClickSpan(int buddyid){
            this.buddyid = buddyid;
        }

        @Override
        public void onClick(View widget) {
            if(mCurrentFragment instanceof ChatFragment) {
                ChatFragment chatFragment = (ChatFragment)mCurrentFragment;
                chatFragment.sendAddBuddyVerifyMsg(buddyid);
            }
        }
    }

    /**
     * 获取视频随机的缩略图
     *
     * @param filePath
     * @return
     */
    public Bitmap getVideoThumbnail(String filePath) {
        Bitmap bitmap = null;
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(filePath);
            bitmap = retriever.getFrameAtTime();
        } catch (IllegalArgumentException e) {
            Logger.getLogger().e("%s", e.getMessage());
        } catch (RuntimeException e) {
            Logger.getLogger().e("%s", e.getMessage());
        } finally {
            try {
                retriever.release();
            } catch (RuntimeException e) {
                Logger.getLogger().e("%s", e.getMessage());
            }
        }

        return bitmap;
    }

    private void setVideoUI(Bitmap previewBitmap, final VideoMessage msg, final VideoMsgViewHolder holder) {
        if (previewBitmap == null)
            return;

        if (msg.isSend(loginUser.getPeerId())) {
            holder.videoView_my_preview.setImageBitmap(previewBitmap);

            holder.button_play_my.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mMode == R.id.NORMAL_MODE) {
                        asyncDownVideoFile(msg, holder);
                    }else {
                        onClickItemCallback(msg, holder.seleced_state_imageview);
                    }
                }
            });

            holder.video_capture_my_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mMode == R.id.NORMAL_MODE) {
                        if(mCurrentFragment instanceof ChatFragment){
                            View view = holder.video_capture_my_layout.getChildAt(0);
                            if(view instanceof VideoView){
                                VideoView videoView = (VideoView)view;
                                if(videoView.isPlaying()){
                                    videoView.stopPlayback();
                                }

                                videoView.setVisibility(View.GONE);
                                holder.videoView_my_preview.setVisibility(View.VISIBLE);
                                holder.button_play_my.setVisibility(View.VISIBLE);
                            }

                            if (!TextUtils.isEmpty(msg.getVideoPath()) && new File(msg.getVideoPath()).exists()){
                                ChatFragment chatFragment = (ChatFragment)mCurrentFragment;
                                chatFragment.playVideo(msg.getVideoPath());
                            }

                        }
                    }else {
                        onClickItemCallback(msg, holder.seleced_state_imageview);
                    }
                }
            });

            holder.video_capture_my_layout.setOnLongClickListener(new OnLongClickListener(){
                @Override
                public boolean onLongClick(View v) {
                    if(mMode == R.id.NORMAL_MODE) {
                        vib.vibrate(15);//只震动15ms，一次 单位：ms
                        if(mCurrentFragment instanceof ChatFragment) {
                            ChatFragment chatFragment = (ChatFragment)mCurrentFragment;
                            chatFragment.showLongPressDialog(msg);
                        }
                        return true;
                    }
                    return false;
                }
            });


        } else {
            holder.videoView_buddy_preview.setImageBitmap(previewBitmap);
            holder.button_play_buddy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mMode == R.id.NORMAL_MODE) {
                        asyncDownVideoFile(msg, holder);
                    }else {
                        onClickItemCallback(msg, holder.seleced_state_imageview);
                    }
                }
            });

            holder.video_capture_buddy_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mMode == R.id.NORMAL_MODE) {
                        if (mCurrentFragment instanceof ChatFragment) {

                            View view = holder.video_capture_buddy_layout.getChildAt(0);
                            if (view instanceof VideoView) {
                                VideoView videoView = (VideoView) view;
                                if (videoView.isPlaying()) {
                                    videoView.stopPlayback();
                                }
                                videoView.setVisibility(View.GONE);
                                holder.videoView_buddy_preview.setVisibility(View.VISIBLE);
                                holder.button_play_buddy.setVisibility(View.VISIBLE);
                            }

                            if (!TextUtils.isEmpty(msg.getVideoPath()) && new File(msg.getVideoPath()).exists()) {
                                ChatFragment chatFragment = (ChatFragment) mCurrentFragment;
                                chatFragment.playVideo(msg.getVideoPath());
                            }
                        }
                    }else {
                        onClickItemCallback(msg, holder.seleced_state_imageview);
                    }
                }
            });

            holder.video_capture_buddy_layout.setOnLongClickListener(new OnLongClickListener(){
                @Override
                public boolean onLongClick(View v) {

                    if(mMode == R.id.NORMAL_MODE) {
                        vib.vibrate(15);//只震动15ms，一次 单位：ms
                        if(mCurrentFragment instanceof ChatFragment) {
                            ChatFragment chatFragment = (ChatFragment)mCurrentFragment;
                            chatFragment.showLongPressDialog(msg);
                        }
                        return true;
                    }
                    return false;
                }
            });

        }
    }

    /**
     * 下载视频缩略图
     *
     * @param msg
     * @param holder
     */
    private void asyncDownVideoThumbnail(final VideoMessage msg, final VideoMsgViewHolder holder) {

        final int index = msg.getVideoUrl().indexOf("?");
        int reqWidth = 480;
        int reqHeight = 480;
        if(index != -1){
            String subStr = msg.getVideoUrl().substring(index+1);
            String[] size = subStr.split("x");
            reqWidth = (int)Double.valueOf(size[0]).doubleValue();
            reqHeight = (int)Double.valueOf(size[1]).doubleValue();
        }

        String filePath = msg.getThumbnailPath();
        if(!TextUtils.isEmpty(filePath)){
            Bitmap previewBitmap = CacheManager.getInstance().getBitmapFormCache(filePath);
            if(previewBitmap != null){
                setVideoUI(previewBitmap, msg, holder);
                return;
            }else if(new File(filePath).exists()){
                previewBitmap = CacheManager.getInstance().addCacheData(filePath, reqWidth, reqHeight);
                setVideoUI(previewBitmap, msg, holder);
                return;
            }
        }


        final String path = CommonFunction.getDirUserTemp() + CommonFunction.getImageFileNameByUrl(msg.getThumbnailUrl());
        msg.setThumbnailPath(path);


        final int req_width = reqWidth;
        final int req_height = reqHeight;

        final File file = new File(path);
        if (!file.exists()) {
            msg.setLoadStatus(MessageConstant.MSG_FILE_UNLOAD);
            //TODO downlaod and play
            String url = msg.getThumbnailUrl();
            new CustomFileDownload(url, file, new CustomFileDownload.DownloadListener() {
                @Override
                public void onDownloadEnd(JSONObject input) {
                    boolean result = input.getBoolean("success");
                    if (result) {
                        msg.setLoadStatus(MessageConstant.MSG_FILE_LOADED_SUCCESS);
                        Bitmap previewBitmap = CacheManager.getInstance().addCacheData(path, req_width, req_height);
                        setVideoUI(previewBitmap, msg, holder);
//                        DBInterface.instance().insertOrUpdateMessage(msg);
                        MessageEntity.insertOrUpdateSingleData(msg);
                    } else {
                        Toast.makeText(context, "下载失败: " + input.getString("error"), Toast.LENGTH_SHORT).show();
                        if(file.exists()){
                            file.delete();
                        }
                    }
                }

                @Override
                public void onProgress(int value) {

                }

            }).execute();
        } else {
            //TODO play
            msg.setLoadStatus(MessageConstant.MSG_FILE_LOADED_SUCCESS);
            Bitmap previewBitmap = CacheManager.getInstance().addCacheData(path, reqWidth, reqHeight);
            setVideoUI(previewBitmap, msg, holder);
//            DBInterface.instance().insertOrUpdateMessage(msg);
            MessageEntity.insertOrUpdateSingleData(msg);

        }
    }

    private void playVideo(final VideoMessage msg, final VideoMsgViewHolder holder) {
        final VideoView videoView = new VideoView(context);
        videoView.setVisibility(View.GONE);

        int index = msg.getVideoUrl().indexOf("?");
        int reqWidth = 480;
        int reqHeight = 480;
        if(index != -1){
            String subStr = msg.getVideoUrl().substring(index+1);
            String[] size = subStr.split("x");
            reqWidth = (int)Double.valueOf(size[0]).doubleValue();
            reqHeight =(int)Double.valueOf(size[1]).doubleValue();
        }

        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(reqWidth, reqHeight); //根据屏幕宽度设置预览控件的尺寸，为了解决预览拉伸问题
        videoView.setLayoutParams(layoutParams);

        //TODO 更新cache?

        if (msg.isSend(loginUser.getPeerId())) {
            videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    holder.videoView_my_preview.setVisibility(View.VISIBLE);
                    holder.button_play_my.setVisibility(View.VISIBLE);
                    holder.video_capture_my_layout.removeView(videoView);
                }
            });

            holder.video_capture_my_layout.addView(videoView, 0);
            videoView.setVisibility(View.VISIBLE);
            //TODO play
            holder.videoView_my_preview.setVisibility(View.GONE);
            holder.button_play_my.setVisibility(View.GONE);

        } else {

            videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    holder.videoView_buddy_preview.setVisibility(View.VISIBLE);
                    holder.button_play_buddy.setVisibility(View.VISIBLE);
                    holder.video_capture_buddy_layout.removeView(videoView);
                }
            });
            holder.video_capture_buddy_layout.addView(videoView, 0);
            videoView.setVisibility(View.VISIBLE);
            //TODO play
            holder.videoView_buddy_preview.setVisibility(View.GONE);
            holder.button_play_buddy.setVisibility(View.GONE);
            holder.roundProgressBar.setVisibility(View.GONE);
        }

        videoView.setVideoPath(msg.getVideoPath());
//                    videoView.setMediaController(new MediaController(context)); //设置了一个播放控制器。
        videoView.start(); //程序运行时自动开始播放视频。
        videoView.requestFocus(); //播放窗口为当前窗口
    }

    private void asyncDownVideoFile(final VideoMessage msg, final VideoMsgViewHolder holder) {
        //TODO 从Cache 取？

        String filePath = msg.getVideoPath();

        if (!TextUtils.isEmpty(filePath) && new File(filePath).exists()) {
            playVideo(msg, holder);//直接加载本地文件
        } else {
            int index = msg.getVideoUrl().indexOf("?");
            String videoUrl = msg.getVideoUrl();
            if(index > 0){
                videoUrl = msg.getVideoUrl().substring(0, index);
            }
            final String path = CommonFunction.getDirUserTemp() + CommonFunction.getImageFileNameByUrl(videoUrl);
            msg.setVideoPath(path);
//            DBInterface.instance().insertOrUpdateMessage(msg);
            MessageEntity.insertOrUpdateSingleData(msg);

            final File file = new File(path);
            if (!file.exists()) {
                //TODO downlaod and play
                holder.button_play_buddy.setVisibility(View.GONE);
                new CustomFileDownload(videoUrl, file, new CustomFileDownload.DownloadListener() {
                    @Override
                    public void onDownloadEnd(JSONObject input) {
                        CommonFunction.hideToast();
                        boolean result = input.getBoolean("success");
                        if (result) {
                            playVideo(msg, holder);
                        } else {
                            Toast.makeText(context, "下载失败: " +input.getString("error"), Toast.LENGTH_SHORT).show();
                            if(file.exists()){
                                file.delete();
                            }
                        }
                    }

                    @Override
                    public void onProgress(int value) {
                        holder.roundProgressBar.setVisibility(View.VISIBLE);
                        holder.roundProgressBar.setValue(value/100.0f);
                    }

                }).execute();
            } else {
                //TODO play
                playVideo(msg, holder);
            }
        }
    }


    private void setVideoMsgData(final VideoMessage msg, final VideoMsgViewHolder holder) {

        initBaseViewHolderData(msg, holder);

        int sessionType = msg.getSessionType();
        if(sessionType == DBConstant.SESSION_TYPE_SINGLE){

        }else {
            boolean isShow = imService.getConfigSp().isShowNick(sessionId);
            if(isShow){
                GroupMemberEntity member = imService.getGroupManager().findGroupMember(sessionId, msg.getFromId());
                UserEntity userEntity = imService.getContactManager().findContact(msg.getFromId());
                String nickName = member.getNickName();
                if(userEntity != null){
                    nickName = !TextUtils.isEmpty(userEntity.getNickName()) ? userEntity.getNickName(): !TextUtils.isEmpty(member.getNickName()) ? member.getNickName() : userEntity.getMainName();
                }
                holder.receiver_nickname.setText(nickName);
                holder.receiver_nickname.setVisibility(View.VISIBLE);
            }else {
                holder.receiver_nickname.setVisibility(View.GONE);
            }
        }

        asyncDownVideoThumbnail(msg, holder);

        int index = msg.getVideoUrl().indexOf("?");
        int reqWidth = 480;
        int reqHeight = 480;
        if(index != -1){
            String subStr = msg.getVideoUrl().substring(index+1);
            String[] size = subStr.split("x");
            reqWidth = (int)Double.valueOf(size[0]).doubleValue();
            reqHeight = (int)Double.valueOf(size[1]).doubleValue();
        }

        if (msg.isSend(loginUser.getPeerId())) {
            holder.im_video_sender_layout.setVisibility(View.VISIBLE);
            holder.im_video_reveive_layout.setVisibility(View.GONE);

            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) holder.videoView_my_preview.getLayoutParams();
            layoutParams.height = reqHeight;//根据屏幕宽度设置预览控件的尺寸，为了解决预览拉伸问题
            layoutParams.width = reqWidth;
            holder.videoView_my_preview.setLayoutParams(layoutParams);

        } else {
            holder.im_video_sender_layout.setVisibility(View.GONE);
            holder.im_video_reveive_layout.setVisibility(View.VISIBLE);

            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) holder.videoView_buddy_preview.getLayoutParams();
            layoutParams.height = reqHeight;//根据屏幕宽度设置预览控件的尺寸，为了解决预览拉伸问题
            layoutParams.width = reqWidth;
            holder.videoView_buddy_preview.setLayoutParams(layoutParams);
        }
    }

    public int getMetadata(String path) {
        int durationValue = 0; //秒数
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        Logger.getLogger().d("%s", path);
        try {
            mmr.setDataSource(path);
            String duration = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            durationValue = (int) (Long.valueOf(duration) / 1000);


        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } finally {
            try {
                mmr.release();
            } catch (RuntimeException e) {
                Logger.getLogger().e("%s", e.getMessage());
            }
            return durationValue;
        }

    }

    /**
     * @param msg
     * @param view
     * @param textView
     * @param unreadStateView 自己发的消息， 传null
     */
    private void setVoiceView(final AudioMessage msg, final VoiceMsgViewHolder viewHolder, final View view, final TextView textView, final ImageView unreadStateView) {
        int durationValue = 0;
//        String path = msg.getAudioPath();
//        File audioFile = new File(path);
//        long fileSize = audioFile.length();
//        if (!TextUtils.isEmpty(path) && fileSize>0) {
//            durationValue = getMetadata(path);
//        }else {
//            String url = msg.getUrl();
//            int index = url.indexOf("?");
//            if(index > 0){
//                durationValue = Integer.valueOf(url.substring(index+1));
//            }
//        }

        //解决getMetadata() 不同品牌的手机算出来的时长不一致的bug
        durationValue = msg.getAudiolength();
        if(durationValue > 0) {
            textView.setText(String.format("%d\"", durationValue));
            textView.setVisibility(View.VISIBLE);
        }else {
            textView.setVisibility(View.GONE);
        }

        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) view.getLayoutParams();
        int screenWidth = CommonFunction.getWidthPx();
        int onePiece = screenWidth / 5;
        int maxLength = screenWidth * 3 / 5;
        int valueLength = maxLength * durationValue / 60; //最大时长60秒
        valueLength += onePiece;
        if (valueLength > maxLength) {
            valueLength = maxLength;
        }
        params.width = valueLength;
        view.setLayoutParams(params);

        if (!msg.isSend(loginUser.getPeerId()) && msg.getReadStatus() == MessageConstant.AUDIO_UNREAD) {
            if (unreadStateView != null)
                unreadStateView.setVisibility(View.VISIBLE);
        } else {
            if (unreadStateView != null)
                unreadStateView.setVisibility(View.GONE);
        }


        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Logger.getLogger().e("%s", "voiceView onClick!!!");

                if(mMode == R.id.NORMAL_MODE){
                    if (!msg.isSend(loginUser.getPeerId()) && msg.getReadStatus() == MessageConstant.AUDIO_UNREAD) {
                        msg.setReadStatus( MessageConstant.AUDIO_READED);
//                        DBInterface.instance().insertOrUpdateMessage(msg);
                        MessageEntity.insertOrUpdateSingleData(msg);
                        if (unreadStateView != null)
                            unreadStateView.setVisibility(View.GONE);
                    }
                    clickVoiceView(msg, viewHolder);
                }else {
                    onClickItemCallback(msg, viewHolder.seleced_state_imageview);
                }
            }
        });

        view.setOnLongClickListener(new OnLongClickListener(){
            @Override
            public boolean onLongClick(View v) {

                if(mMode == R.id.NORMAL_MODE){
                    vib.vibrate(15);//只震动15ms，一次 单位：ms
                    if(mCurrentFragment instanceof ChatFragment) {
                        ChatFragment chatFragment = (ChatFragment)mCurrentFragment;
                        chatFragment.showLongPressDialog(msg);
                    }
                    return true;
                }
                return false;

            }
        });

    }

    public void releaseVoiceResource() {

        if (animationDrawable != null) {
            animationDrawable.stop();
            animationDrawable = null;
        }

        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    private void stopPlayVoiceMsg() {
        mIsVoicePlaying = false;
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            Logger.getLogger().e("2. mediaPlayer.isPlaying(): %s" , mediaPlayer.isPlaying()?"true":"false");
            mediaPlayer.release();
            mediaPlayer = null;
            stopVoiceAnimation();
        }
    }

    private VoiceMsgViewHolder currentVoiceMsgViewHolder = null;
    private boolean mIsVoicePlaying = false;
    private AudioMessage currentVoiceMsg = null;

    private void playVoice(final AudioMessage msg, final VoiceMsgViewHolder holder) {

        String voicePath = msg.getAudioPath();
        if (mIsVoicePlaying && currentVoiceMsgViewHolder == holder) {
            stopPlayVoiceMsg();
            return;
        }else {
            stopPlayVoiceMsg();
        }

        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    stopPlayVoiceMsg();
                }
            });
        }

        mIsVoicePlaying = true;
        currentVoiceMsgViewHolder = holder; //标记当前播放的imageView和item
        currentVoiceMsg = msg;

        startVoiceAnimation();

        try {
            mediaPlayer.setDataSource(voicePath);
            mediaPlayer.prepare();
            mediaPlayer.start();

        } catch (Exception e) {
            Logger.getLogger().e("%s", e.getMessage());
            stopPlayVoiceMsg();
        }
    }

    //TODO 有复用bug
    private void startVoiceAnimation() {
        AudioMessage msg = (AudioMessage)getItem(currentVoiceMsgViewHolder.getPosition());
        if(!msg.getId().equals(currentVoiceMsg.getId())){
            boolean isMyself = msg.isSend(loginUser.getPeerId());
            if (isMyself) {
                currentVoiceMsgViewHolder.voice_msg_my_img.setImageResource(R.mipmap.volumn_send_default);
            } else {
                currentVoiceMsgViewHolder.voice_msg_buddy_img.setImageResource(R.mipmap.volumn_recv_default);
            }
            return;
        }

        boolean isMyself = currentVoiceMsg.isSend(loginUser.getPeerId());
        ImageView voiceMsgImgView = null;
        if (isMyself) {
            voiceMsgImgView = currentVoiceMsgViewHolder.voice_msg_my_img;
            voiceMsgImgView.setImageResource(R.drawable.msg_voice_anim_send_play);
        } else {
            voiceMsgImgView = currentVoiceMsgViewHolder.voice_msg_buddy_img;
            voiceMsgImgView.setImageResource(R.drawable.msg_voice_anim_recv_play);
        }
        animationDrawable = (AnimationDrawable) voiceMsgImgView.getDrawable();
        if (animationDrawable != null) {
            animationDrawable.start();
        }

    }

    private void stopVoiceAnimation() {

        if (animationDrawable == null || currentVoiceMsgViewHolder == null) {
            return;
        }else {
            animationDrawable.stop();
        }
        boolean isMyself = currentVoiceMsg.isSend(loginUser.getPeerId());
        if (isMyself) {
            currentVoiceMsgViewHolder.voice_msg_my_img.setImageResource(R.mipmap.volumn_send_default);
        } else {
            currentVoiceMsgViewHolder.voice_msg_buddy_img.setImageResource(R.mipmap.volumn_recv_default);
        }

    }

    private void clickVoiceView(final AudioMessage msg, final VoiceMsgViewHolder holder) {
        String filePath = msg.getAudioPath();

        if (!TextUtils.isEmpty(filePath)) {
            File file = new File(filePath); //直接加载本地文件
            if (file.exists()) {
                //TODO Play
                playVoice(msg, holder);
            }
        }
    }

    private void asyncDownLoadAudioFile(final AudioMessage msg, final VoiceMsgViewHolder holder) {

        String filePath = msg.getAudioPath();
        if (!TextUtils.isEmpty(filePath) && new File(filePath).length()>0) {
//            msg.setAudioPath(filePath);
//            msg.setLoadStatus(MessageConstant.MSG_FILE_LOADED_SUCCESS);
//            DBInterface.instance().insertOrUpdateMessage(msg);
        } else {

            String fileUrl = msg.getUrl();
            int index = fileUrl.indexOf("?");
            if(index > 0){
                fileUrl = fileUrl.substring(0, index);
            }
            filePath = CommonFunction.getDirUserTemp() + CommonFunction.getImageFileNameByUrl(fileUrl);
            msg.setAudioPath(filePath);

            final File file = new File(filePath);
            if (!file.exists()) {
                msg.setLoadStatus(MessageConstant.MSG_FILE_UNLOAD);
                String url = msg.getUrl();
                new CustomFileDownload(url, file, new CustomFileDownload.DownloadListener() {
                    @Override
                    public void onDownloadEnd(JSONObject input) {
                        boolean result = input.getBoolean("success");
                        if (result) {
                            msg.setAudioPath(input.getString("localPath"));
                            msg.setLoadStatus(MessageConstant.MSG_FILE_LOADED_SUCCESS);
//                            DBInterface.instance().insertOrUpdateMessage(msg);
                            MessageEntity.insertOrUpdateSingleData(msg);

                            if (msg.isSend(loginUser.getPeerId())) {
                                setVoiceView(msg, holder, holder.voice_msg_my_layout, holder.voice_msg_my_text, null);
                            } else {
                                setVoiceView(msg, holder, holder.voice_msg_buddy_layout, holder.voice_msg_buddy_text, holder.voice_msg_read_state);
                            }
                        } else {
                            Toast.makeText(context, "下载失败: " +input.getString("error"), Toast.LENGTH_SHORT).show();
                            if(file.exists()){
                                file.delete();
                            }
                        }
                    }

                    @Override
                    public void onProgress(int value) {

                    }

                }).execute();
            } else {
                msg.setLoadStatus(MessageConstant.MSG_FILE_LOADED_SUCCESS);
//                DBInterface.instance().insertOrUpdateMessage(msg);
                MessageEntity.insertOrUpdateSingleData(msg);
            }
        }
    }

    private void setVoiceMsgData(final AudioMessage msg, final VoiceMsgViewHolder holder) {

        initBaseViewHolderData(msg, holder);

        int sessionType = msg.getSessionType();
        if(sessionType == DBConstant.SESSION_TYPE_SINGLE){

        }else {

            boolean isShow = imService.getConfigSp().isShowNick(sessionId);
            if(isShow){
                GroupMemberEntity member = imService.getGroupManager().findGroupMember(sessionId, msg.getFromId());
                UserEntity userEntity = imService.getContactManager().findContact(msg.getFromId());
                String nickName = member.getNickName();
                if(userEntity != null){
                    nickName = !TextUtils.isEmpty(userEntity.getNickName()) ? userEntity.getNickName(): !TextUtils.isEmpty(member.getNickName()) ? member.getNickName() : userEntity.getMainName();
                }
                holder.receiver_nickname.setText(nickName);
                holder.receiver_nickname.setVisibility(View.VISIBLE);
            }else {
                holder.receiver_nickname.setVisibility(View.GONE);
            }

        }

        if (msg.isSend(loginUser.getPeerId())) {
            holder.im_voice_sender_layout.setVisibility(View.VISIBLE);
            holder.im_voice_reveive_layout.setVisibility(View.GONE);
            asyncDownLoadAudioFile(msg, holder);
            setVoiceView(msg, holder, holder.voice_msg_my_layout, holder.voice_msg_my_text, null);
        } else {
            holder.im_voice_sender_layout.setVisibility(View.GONE);
            holder.im_voice_reveive_layout.setVisibility(View.VISIBLE);
            asyncDownLoadAudioFile(msg, holder);
            setVoiceView(msg, holder, holder.voice_msg_buddy_layout, holder.voice_msg_buddy_text, holder.voice_msg_read_state);

        }

    }


    private void setImageMsgData(final ImageMessage msg, final ImageMsgViewHolder holder) {

        initBaseViewHolderData(msg, holder);

        int sessionType = msg.getSessionType();
        if(sessionType == DBConstant.SESSION_TYPE_SINGLE){

        }else {
            boolean isShow = imService.getConfigSp().isShowNick(sessionId);
            if(isShow){
                GroupMemberEntity member = imService.getGroupManager().findGroupMember(sessionId, msg.getFromId());
                UserEntity userEntity = imService.getContactManager().findContact(msg.getFromId());
                String nickName = member.getNickName();
                if(userEntity != null){
                    nickName = !TextUtils.isEmpty(userEntity.getNickName()) ? userEntity.getNickName(): !TextUtils.isEmpty(member.getNickName()) ? member.getNickName() : userEntity.getMainName();
                }
                holder.receiver_nickname.setText(nickName);
                holder.receiver_nickname.setVisibility(View.VISIBLE);
            }else {
                holder.receiver_nickname.setVisibility(View.GONE);
            }
        }

        if (msg.isSend(loginUser.getPeerId())) {
            holder.im_image_sender_layout.setVisibility(View.VISIBLE);
            holder.im_plain_reveive_layout.setVisibility(View.GONE);
            setImageView(msg, holder.img_chat_my_msg, holder.seleced_state_imageview);
        } else {
            holder.im_image_sender_layout.setVisibility(View.GONE);
            holder.im_plain_reveive_layout.setVisibility(View.VISIBLE);
            setImageView(msg, holder.img_chat_buddy_msg, holder.seleced_state_imageview);
        }
    }

    private List<Integer> getReqSizeFromBitmap(int width, int height){
        if(width == 0 || height == 0)
            return null;

        int screenWidth = CommonFunction.getWidthPx();
        float radio = (float)height/width;
        if(width < height){
            width = screenWidth/3;
        }else {
            if(width > screenWidth/2){
                width = screenWidth/2;
            }else if(width < screenWidth/3){
                width = screenWidth/3;
            }
        }

        List<Integer> size = new ArrayList<>();
        size.add(width);
        size.add((int)Math.floor(width*radio));

        return size;
    }

    private void GlideView(final ImageMessage message, final Bitmap bitmap, final ImageView imageView, final String filePath, final ImageView seleced_state_imageview) {
        if(bitmap == null || imageView == null)
            return;

        final LinearLayout.LayoutParams params = (LinearLayout.LayoutParams)imageView.getLayoutParams();
        List<Integer> size = getReqSizeFromBitmap(bitmap.getWidth(), bitmap.getHeight());
        if(size == null)
            return;

        params.width = size.get(0);
        params.height = size.get(1);

        imageView.setLayoutParams(params);
        imageView.setImageBitmap(bitmap);

//        new AsyncTask<Void, Void, byte[]>() {
//
//            @Override
//            protected byte[] doInBackground(Void... params) {
//                ByteArrayOutputStream baos = new ByteArrayOutputStream();
//                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);//这步比较耗时，故放在后台中
//                return baos.toByteArray();
//            }
//
//            @Override
//            protected void onPostExecute(byte[] byteArray) {
//                super.onPostExecute(byteArray);
//
//                Glide.with(mCurrentFragment)
//                        .load(byteArray)
//                        .dontAnimate()
//                        .placeholder(R.drawable.msg_pic_fail)
//                        .error(R.drawable.msg_pic_fail)
//                        .diskCacheStrategy(DiskCacheStrategy.NONE) //不缓存到SD卡
//                        .skipMemoryCache(true) //不缓存内存
//                        .into(imageView);
//
//            }
//        }.execute();


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mMode == R.id.NORMAL_MODE) {
                    if (mCurrentFragment instanceof ChatFragment) {
                        ChatFragment chatFragment = (ChatFragment) mCurrentFragment;
                        //TODO
                        ArrayList<String> imagePaths = getAllImagePaths();
                        int index = imagePaths.indexOf(filePath);
                        chatFragment.preViewImage(imagePaths, index);
                    }
                }else {
                    onClickItemCallback(message, seleced_state_imageview);
                }
            }
        });

        imageView.setOnLongClickListener(new OnLongClickListener(){
            @Override
            public boolean onLongClick(View v) {

                if(mMode == R.id.NORMAL_MODE) {
                    vib.vibrate(15);//只震动15ms，一次 单位：ms
                    if(mCurrentFragment instanceof ChatFragment) {
                        ChatFragment chatFragment = (ChatFragment)mCurrentFragment;
                        chatFragment.showLongPressDialog(message);
                    }
                    return true;
                }
                return false;
            }
        });

    }

    /**
     * 获取所有图片的本地路径
     * @return
     */
    private ArrayList<String> getAllImagePaths(){
        if(mMsgList == null)
            return null;

        ArrayList<String> paths = new ArrayList<>();
        for(MessageEntity msg : mMsgList){
            if(msg instanceof ImageMessage){
                ImageMessage imageMessage = (ImageMessage)msg;
                paths.add(imageMessage.getPath());
            }
        }

        return paths;
    }

    /**
     * 当满足filePath不为空、缓存有效或filePath对应的文件存在时，取缓存使用
     * 否则，试图从fileUrl下手，尝试本地查找和远程下载
     */
    private void setImageView(ImageMessage msg, ImageView imageView, final ImageView seleced_state_imageview) {

        imageView.setVisibility(View.VISIBLE);
        String filePath = msg.getPath();
        if(!TextUtils.isEmpty(filePath)){
            Bitmap bitmap = CacheManager.getInstance().getBitmapFormCache(filePath);
            if(bitmap != null){
                GlideView(msg, bitmap, imageView, filePath, seleced_state_imageview);
                return;
            }else if(new File(filePath).exists()){
                //todo 异步处理
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(filePath, options);
                List<Integer> size = getReqSizeFromBitmap(options.outWidth, options.outHeight);
                if(size != null) {
                    int reqWidth = size.get(0);
                    int reqHeight = size.get(1);
                    bitmap = CacheManager.getInstance().addCacheData(filePath, reqWidth, reqHeight);
                    GlideView(msg, bitmap, imageView, filePath, seleced_state_imageview);
                    return;
                }
            }
        }


        String fileUrl = msg.getUrl();
        if(TextUtils.isEmpty(fileUrl))
            return;

        int index = fileUrl.indexOf("?");
        if(index > 0){
            fileUrl = fileUrl.substring(0, index);
        }
        filePath = CommonFunction.getDirUserTemp() + CommonFunction.getImageFileNameByUrl(fileUrl);
        msg.setPath(filePath);

        if (!new File(filePath).exists()) {
            msg.setLoadStatus(MessageConstant.MSG_FILE_UNLOAD);
            asyncLoadImage(msg, imageView, seleced_state_imageview);
        } else {
            msg.setLoadStatus(MessageConstant.MSG_FILE_LOADED_SUCCESS);
//            DBInterface.instance().insertOrUpdateMessage(msg);
            MessageEntity.insertOrUpdateSingleData(msg);

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(filePath, options);
            List<Integer> size = getReqSizeFromBitmap(options.outWidth, options.outHeight);
            if(size != null) {
                int reqWidth = size.get(0);
                int reqHeight = size.get(1);
                Bitmap bitmap = CacheManager.getInstance().addCacheData(filePath, reqWidth, reqHeight);
                GlideView(msg, bitmap, imageView, filePath, seleced_state_imageview);
            }

        }
    }


    private Bitmap drawableToBitamp(Drawable drawable) {
        Bitmap bitmap;
        int w = drawable.getIntrinsicWidth();
        int h = drawable.getIntrinsicHeight();
        Bitmap.Config config = Bitmap.Config.RGB_565;
        bitmap = Bitmap.createBitmap(w,h,config);
        //注意，下面三行代码要用到，否在在View或者surfaceview里的canvas.drawBitmap会看不到图
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, w, h);
        drawable.draw(canvas);
        return bitmap;
    }

    protected void asyncLoadImage(final ImageMessage message, final ImageView iv, final ImageView seleced_state_imageview) {
        String imageUrl = message.getUrl();
        LazyHeaders.Builder builder = new LazyHeaders.Builder();
        builder.addHeader("clientId", Utils.getDeviceId());
        builder.addHeader("refreshTokenGrantType", "refresh_token");
        builder.addHeader("refreshToken", Preferences.getRefreshToken());
//        builder.addHeader("tokenValue", Preferences.getAccessToken());
        LazyHeaders headers = builder.build();
        GlideUrl glideUrl = new GlideUrl(imageUrl, headers);

        int index = imageUrl.indexOf("?");
        String subStr = imageUrl.substring(index+1);
        String[] size = subStr.split("[\\*, x]{1}");
        final int reqWidth = (int)Double.valueOf(size[0]).doubleValue();
        final int reqHeight = (int)Double.valueOf(size[1]).doubleValue();


        //根据需下载的图片初始化控件大小
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams)iv.getLayoutParams();
        List<Integer> reqSize = getReqSizeFromBitmap(reqWidth, reqHeight);
        params.width = reqSize.get(0);
        params.height = reqSize.get(1);

        iv.setLayoutParams(params);

        Glide.with(mCurrentFragment.getActivity())
                .load(glideUrl)
                .override(reqWidth, reqHeight)
                .listener(new RequestListener<GlideUrl, GlideDrawable>() {
                    @Override
                    public boolean onException(Exception e, GlideUrl model, Target<GlideDrawable> target, boolean isFirstResource) {
                        if(e != null) {
                            e.printStackTrace();
                            CommonFunction.showToast(TextUtils.isEmpty(e.getMessage()) ? "异常" : e.getMessage());
                        }
//                        "下载失败: " +input.getString("error")
                        File file = new File(message.getPath());
                        if(file.exists()){
                            file.delete();
                        }

                        message.setLoadStatus(MessageConstant.MSG_FILE_LOADED_FAILURE);
//                        DBInterface.instance().insertOrUpdateMessage(message);
                        MessageEntity.insertOrUpdateSingleData(message);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(GlideDrawable resource, GlideUrl model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                        final Bitmap bitmap = drawableToBitamp(resource);
                        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        GlideView(message, bitmap, iv, message.getPath(), seleced_state_imageview);

                        new AsyncTask<Void, Void, Void>() {

                            @Override
                            protected Void doInBackground(Void... params) {
                                try {
                                    message.setLoadStatus(MessageConstant.MSG_FILE_LOADED_SUCCESS);
//                                    DBInterface.instance().insertOrUpdateMessage(message);
                                    MessageEntity.insertOrUpdateSingleData(message);

                                    File file = new File(message.getPath());
                                    FileOutputStream os = new FileOutputStream(file);
                                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, os);
                                    os.flush();
                                    os.close();

                                    CacheManager.getInstance().addCacheData(file.getPath(), reqWidth, reqHeight);

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                return null;
                            }

                            @Override
                            protected void onPostExecute(Void aVoid) {
                                super.onPostExecute(aVoid);
                                GlideView(message, bitmap, iv, message.getPath(), seleced_state_imageview);
                            }
                        }.execute();

                        return false;
                    }
                })
                .error(R.mipmap.msg_pic_fail)
                .placeholder(R.mipmap.msg_pic_fail)
                .diskCacheStrategy(DiskCacheStrategy.NONE) //不缓存到SD卡
                .skipMemoryCache(true) //不缓存内存
                .into(iv);

    }


    private void setMsgDateTime(final MessageEntity message, final TextView dateTimeView){

        if(showTimeMsgIdList.contains(message)){
            dateTimeView.setVisibility(View.VISIBLE);


            new AsyncTask<Void, Void, String>() {

                @Override
                protected String doInBackground(Void... params) {
                    String dateStr = CommonFunction.getDisplayTimeFormat(new Date(message.getCreated()));
                    return dateStr;
                }

                @Override
                protected void onPostExecute(String dateStr) {
                    super.onPostExecute(dateStr);
                    dateTimeView.setText(dateStr);
                }
            }.execute();

        }else {
            dateTimeView.setVisibility(View.GONE);
        }
    }

    private void setMsgState(ImageView msg_state, int msgState) {
        switch (msgState) {
            case MessageConstant.MSG_SUCCESS:
                msg_state.clearAnimation();
                msg_state.setVisibility(View.INVISIBLE);
                break;
            case MessageConstant.MSG_FAILURE:
            case MessageConstant.MSG_FAIL_RESULT_CODE:
                msg_state.setVisibility(View.VISIBLE);
                msg_state.clearAnimation();
                msg_state.setImageResource(R.mipmap.msg_failed_img);
                break;
            case MessageConstant.MSG_SENDING:
                msg_state.setVisibility(View.VISIBLE);
                msg_state.setImageResource(R.mipmap.msg_loading);
                msg_state.startAnimation(loadingAnim);
                break;
        }

    }

    private void showReSendDialog(final MessageEntity msg, final msgBaseViewHolder holder){
        final CustomConfirmDialog.Builder builder = new CustomConfirmDialog.Builder(context);
        builder.setPositiveBtn(R.string.g_resend, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                dialog.dismiss();
                if(mCurrentFragment instanceof ChatFragment) {
                    ChatFragment chatFragment = (ChatFragment)mCurrentFragment;
                    msg.setStatus(MessageConstant.MSG_SENDING);
                    setMsgState(holder.msg_state, msg.getStatus());
                    chatFragment.sendMsgToServer(msg, false);
                }

            }
        });
        builder.setNegativeBtn(R.string.g_cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.setTitle("重发该消息？");
        CustomConfirmDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void replaceCallMsg2(final TextMessage message, final TextView textView, final ImageView seleced_state_imageview) {
        Pattern pattern = Pattern.compile("<img src=\"extra/");
        Matcher matcher = pattern.matcher(message.getContent());
        if(matcher.find()){
            new AsyncTask<Void, Void, Spanned>(){
                @Override
                protected Spanned doInBackground(Void... params) {

                    String replaceContent = message.getContent();
                    //替换电话图标
                    Spanned htmlStr = Html.fromHtml(replaceContent, new Html.ImageGetter() {
                        @Override
                        public Drawable getDrawable(String source) {
                            AssetManager assetManager = context.getAssets();
                            BitmapDrawable drawable = null;
                            try {
                                InputStream in = assetManager.open(source);
                                Bitmap bmp = BitmapFactory.decodeStream(in);
                                drawable = new BitmapDrawable(bmp);
                                drawable.setBounds(0, 0, CommonFunction.dip2px(26), CommonFunction.dip2px(13));
                            }catch (IOException e){
                                e.printStackTrace();
                            }

                            return drawable;
                        }
                    }, null);
                    return htmlStr;
                }

                @Override
                protected void onPostExecute(Spanned s) {
                    super.onPostExecute(s);
                    textView.setText(s);
                    textView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if(mMode == R.id.NORMAL_MODE) {
                                if(mCurrentFragment instanceof ChatFragment) {
                                    ChatFragment chatFragment = (ChatFragment)mCurrentFragment;
                                    chatFragment.showCallDialog();
                                }
                            }else {
                                if(message != null && seleced_state_imageview != null){
                                    onClickItemCallback(message, seleced_state_imageview);
                                }
                            }
                        }
                    });
                }
            }.execute();

        }else {
            textView.setText(message.getContent());
        }
    }

    private void replaceCallMsg(final TextMessage message, final TextView textView, final ImageView seleced_state_imageview) {

        final String text = message.getContent();
        final String callStr = "通话时长";
        if(!text.startsWith(callStr))
            return;

        if(mMode == R.id.NORMAL_MODE) {
            textView.setMovementMethod(LinkMovementClickMethod.getInstance()); //必须：设置超链接为可点击状态
            // 设置TextView的内容
            textView.setText(Html.fromHtml(text,null, new Html.TagHandler() {
                @Override
                public void handleTag(boolean opening, String tag, Editable output, XMLReader xmlReader) {
                    String str = output.toString();
                    Pattern pattern = Pattern.compile(text, Pattern.CASE_INSENSITIVE);
                    Matcher matcher = pattern.matcher(str);

                    while (matcher.find()) {
                        int start = matcher.start();
                        int end = matcher.end();
//                        output.setSpan(new CallClickSpan(message, seleced_state_imageview), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        output.setSpan(new CallClickSpan(), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    }

                }
            }));
        }else {
            // 设置TextView的内容
            textView.setText(Html.fromHtml(text,null, null));
        }

    }

    class CallClickSpan extends ClickableSpan{
        private MessageEntity messageEntity;
        private ImageView seleced_state_imageview;
        CallClickSpan(MessageEntity messageEntity, ImageView seleced_state_imageview){
            super();
            this.messageEntity = messageEntity;
            this.seleced_state_imageview = seleced_state_imageview;
        }

        CallClickSpan(){
            super();
        }

        @Override
        public void onClick(View widget) {
            if(mMode == R.id.NORMAL_MODE) {
                if(mCurrentFragment instanceof ChatFragment) {
                    ChatFragment chatFragment = (ChatFragment)mCurrentFragment;
                    chatFragment.showCallDialog();
                }
            }else {
                if(messageEntity != null && seleced_state_imageview != null){
                    //bug: 会连续触发两次,所以这里不依赖CallClickSpan的onClick 改变多选状态
                    onClickItemCallback(messageEntity, seleced_state_imageview);
                }
            }
        }
    }

    private void setTextMsgData(final TextMessage msg, final textMsgViewHolder holder){

        initBaseViewHolderData(msg, holder);

        int sessionType = msg.getSessionType();
        if(sessionType == DBConstant.SESSION_TYPE_SINGLE){

        }else {
            boolean isShow = imService.getConfigSp().isShowNick(sessionId);
            if(isShow){
                GroupMemberEntity member = imService.getGroupManager().findGroupMember(sessionId, msg.getFromId());
                UserEntity userEntity = imService.getContactManager().findContact(msg.getFromId());
                String nickName = member.getNickName();
                if(userEntity != null){
                    nickName = !TextUtils.isEmpty(userEntity.getNickName()) ? userEntity.getNickName(): !TextUtils.isEmpty(member.getNickName()) ? member.getNickName() : userEntity.getMainName();
                }

                holder.receiver_nickname.setText(nickName);
                holder.receiver_nickname.setVisibility(View.VISIBLE);
            }else {
                holder.receiver_nickname.setVisibility(View.GONE);
            }
        }
        if (msg.isSend(loginUser.getPeerId())) {
            holder.im_plain_sender_layout.setVisibility(View.VISIBLE);
            holder.im_plain_reveive_layout.setVisibility(View.GONE);
            setTextView(msg, holder.text_chat_my_msg, holder.seleced_state_imageview);
        } else {
            holder.im_plain_sender_layout.setVisibility(View.GONE);
            holder.im_plain_reveive_layout.setVisibility(View.VISIBLE);
            setTextView(msg, holder.text_chat_buddy_msg, holder.seleced_state_imageview);
        }
    }

    private void setTextView(final TextMessage msg, final TextView chat_text_view, final ImageView seleced_state_imageview){
        final String content = msg.getContent();
        if(content.length() < 10){
            chat_text_view.setGravity(Gravity.CENTER);
        } else{
            chat_text_view.setGravity(Gravity.NO_GRAVITY);
        }

        Pattern pattern = Pattern.compile("\\[[\\u4e00-\\u9fa5, OK, NO]{1,3}\\]");
        Matcher mather =  pattern.matcher(content);
        if (mather.find()){
            // 设置TextView的内容
            if(!TextUtils.isEmpty(content)){

                new AsyncTask<Void, Void, Spanned>(){
                    @Override
                    protected Spanned doInBackground(Void... params) {

                        String replaceContent = content;
                        replaceContent = replaceContent.replaceAll(" ", "&nbsp;");
                        replaceContent = replaceContent.replaceAll("\r\n", "<br>");
                        replaceContent = replaceContent.replaceAll("\r","<br>");
                        replaceContent = replaceContent.replaceAll("\n","<br>");

                        //替换emoji表情图片
                        final String replaceStr = FaceManager.getInstance().replaceFaceChacter(replaceContent);

                        Spanned htmlStr = Html.fromHtml(replaceStr, new Html.ImageGetter() {
                            @Override
                            public Drawable getDrawable(String source) {
                                AssetManager assetManager = context.getAssets();
                                BitmapDrawable drawable = null;
                                try {
                                    InputStream in = assetManager.open(source);
                                    Bitmap bmp = BitmapFactory.decodeStream(in);
                                    drawable = new BitmapDrawable(bmp);
//                            drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());//图像很小 19px,原因待查
                                    drawable.setBounds(0, 0, CommonFunction.dip2px(19), CommonFunction.dip2px(19));
                                }catch (IOException e){
                                    e.printStackTrace();
                                }

                                return drawable;
                            }
                        }, null);
                        return htmlStr;
                    }

                    @Override
                    protected void onPostExecute(Spanned s) {
                        super.onPostExecute(s);
                        chat_text_view.setText(s);
                    }
                }.execute();

            }
        }else {
            int sessionType = msg.getSessionType();
            if(sessionType == DBConstant.SESSION_TYPE_SINGLE){
                replaceCallMsg2(msg, chat_text_view, seleced_state_imageview);
            }else {
                chat_text_view.setText(msg.getContent());
            }
        }


        chat_text_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mMode == R.id.MULTIPLE_CHOICE_MODE) {
                    onClickItemCallback(msg, seleced_state_imageview);
                }
            }
        });

        chat_text_view.setOnLongClickListener(new OnLongClickListener(){
            @Override
            public boolean onLongClick(View v) {

                if(mMode == R.id.NORMAL_MODE) {
                    vib.vibrate(15);//只震动15ms，一次 单位：ms
                    if (mCurrentFragment instanceof ChatFragment) {
                        ChatFragment chatFragment = (ChatFragment) mCurrentFragment;
                        chatFragment.showLongPressDialog(msg);
                    }
                    return true;
                }
                return false;
            }
        });

    }


    private View getTextMsgView(TextMessage msg, View convertView){

        textMsgViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.im_send_text_layout, null);
            holder = new textMsgViewHolder(convertView);
        } else {
            Object object = convertView.getTag();
            if(object instanceof textMsgViewHolder){
                holder = (textMsgViewHolder)object;
            }else {
                convertView = inflater.inflate(R.layout.im_send_text_layout, null);
                holder = new textMsgViewHolder(convertView);
            }
        }

        setTextMsgData(msg, holder);
        return convertView;
    }

    private View getImageMsgView(ImageMessage msg, View convertView){
        ImageMsgViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.im_send_image_layout, null);
            holder = new ImageMsgViewHolder(convertView);
        } else {
            Object object = convertView.getTag();
            if(object instanceof ImageMsgViewHolder){
                holder = (ImageMsgViewHolder)object;
            }else {
                convertView = inflater.inflate(R.layout.im_send_image_layout, null);
                holder = new ImageMsgViewHolder(convertView);
            }
        }

        setImageMsgData(msg, holder);
        return convertView;
    }

    private View getVoiceMsgView(int position, AudioMessage msg, View convertView){
        VoiceMsgViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.im_send_voice_layout, null);
            holder = new VoiceMsgViewHolder(convertView);
        } else {
            Object object = convertView.getTag();
            if(object instanceof VoiceMsgViewHolder){
                holder = (VoiceMsgViewHolder)object;
            }else {
                convertView = inflater.inflate(R.layout.im_send_voice_layout, null);
                holder = new VoiceMsgViewHolder(convertView);
            }
        }

        holder.setPosition(position);
        setVoiceMsgData(msg, holder);
        return convertView;
    }

    private View getVideoMsgView(VideoMessage msg, View convertView){
        VideoMsgViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.im_send_video_layout, null);
            holder = new VideoMsgViewHolder(convertView);
        } else {
            Object object = convertView.getTag();
            if(object instanceof VideoMsgViewHolder){
                holder = (VideoMsgViewHolder)object;
            }else {
                convertView = inflater.inflate(R.layout.im_send_video_layout, null);
                holder = new VideoMsgViewHolder(convertView);
            }
        }

        setVideoMsgData(msg, holder);
        return convertView;
    }

    private View getSystemMsgView(TextMessage msg, View convertView){
        SystemMsgViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.im_system_layout, null);
            holder = new SystemMsgViewHolder(convertView);
        } else {
            Object object = convertView.getTag();
            if(object instanceof VideoMsgViewHolder){
                holder = (SystemMsgViewHolder)object;
            }else {
                convertView = inflater.inflate(R.layout.im_system_layout, null);
                holder = new SystemMsgViewHolder(convertView);
            }
        }

        setSystemMsgData(msg, holder);
        return convertView;
    }


    private void initBaseViewHolderData(final MessageEntity msg, final msgBaseViewHolder holder){

        if(mMode == R.id.NORMAL_MODE){
            holder.seleced_state_imageview.setVisibility(View.GONE);
        }else if(mMode == R.id.MULTIPLE_CHOICE_MODE){
            holder.seleced_state_imageview.setVisibility(View.VISIBLE);
            Drawable drawable =  context.getResources().getDrawable(R.mipmap.checkbox_off);
            if(allSelectedObject().contains(msg)){
                drawable = context.getResources().getDrawable(R.mipmap.checkbox_on);
            }
            holder.seleced_state_imageview.setImageDrawable(drawable);
        }

        setMsgDateTime(msg, holder.send_msg_date);

        final UserEntity userEntity = imService.getContactManager().findContact(msg.getFromId());
        if (msg.isSend(loginUser.getPeerId())) {
            CommonFunction.setHeadIconImageView(holder.icon_chat_me, userEntity);
            setMsgState(holder.msg_state, msg.getStatus());

            holder.icon_chat_me.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mMode == R.id.NORMAL_MODE){
                        if(mCurrentFragment instanceof ChatFragment) {
                            ChatFragment chatFragment = (ChatFragment)mCurrentFragment;
                            chatFragment.JumpToPersonalInfo(userEntity.getPeerId());
                        }
                    }else {
                        onClickItemCallback(msg, holder.seleced_state_imageview);
                    }

                }
            });

            holder.msg_state.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(mMode == R.id.NORMAL_MODE){
                        if(msg.getStatus() == MessageConstant.MSG_FAILURE || msg.getStatus() == MessageConstant.MSG_FAIL_RESULT_CODE){//失败的时候才能发送
                            showReSendDialog(msg, holder);
                        }
                    }else {
                        onClickItemCallback(msg, holder.seleced_state_imageview);
                    }
                }
            });

        } else {
            CommonFunction.setHeadIconImageView(holder.icon_chat_buddy, userEntity);
            holder.icon_chat_buddy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mMode == R.id.NORMAL_MODE){
                        if (mCurrentFragment instanceof ChatFragment) {
                            ChatFragment chatFragment = (ChatFragment) mCurrentFragment;
                            chatFragment.JumpToPersonalInfo(userEntity.getPeerId());
                        }
                    }else {
                        onClickItemCallback(msg, holder.seleced_state_imageview);
                    }
                }
            });
        }

        holder.content_body.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(mMode != R.id.MULTIPLE_CHOICE_MODE) {
                    return false;
                }

                if(event.getAction() == MotionEvent.ACTION_DOWN) {
                    return true;
                }
                if(event.getAction() == MotionEvent.ACTION_UP) {
                    onClickItemCallback(msg, holder.seleced_state_imageview);
                }
                return false;
            }
        });
    }

    private void onClickItemCallback(final MessageEntity msg, final ImageView state_imageview){

        Logger.getLogger().e("onItemClick ");
        if(mMode == R.id.MULTIPLE_CHOICE_MODE){
            if(!allSelectedObject().contains(msg)){
                addSelectedObject(msg);
            }else {
                removeSelectedObject(msg);
            }

            state_imageview.setVisibility(View.VISIBLE);
            Drawable drawable = context.getResources().getDrawable(R.mipmap.checkbox_off);
            if(allSelectedObject().contains(msg)){
                drawable = context.getResources().getDrawable(R.mipmap.checkbox_on);
            }
            state_imageview.setImageDrawable(drawable);

            if (mCurrentFragment instanceof ChatFragment) {
                ChatFragment chatFragment = (ChatFragment) mCurrentFragment;
                chatFragment.setMoreOperationBtnEnableState();
            }

        }
    }

    static class msgDateViewHolder extends BaseClickableViewHolder {
        TextView send_msg_date;

        msgDateViewHolder(View convertView){
            super(convertView, false);
            send_msg_date = (TextView) convertView.findViewById(R.id.send_msg_date);
        }
    }

    static class msgBaseViewHolder extends msgDateViewHolder{
        CircleImageView icon_chat_me;
        CircleImageView icon_chat_buddy;
        ImageView msg_state;
        ImageView seleced_state_imageview;
        View content_body;
        msgBaseViewHolder(View convertView){
            super(convertView);
            icon_chat_me = (CircleImageView)convertView.findViewById(R.id.icon_chat_me);
            icon_chat_buddy = (CircleImageView)convertView.findViewById(R.id.icon_chat_buddy);
            msg_state = (ImageView)convertView.findViewById(R.id.msg_state);
            seleced_state_imageview = (ImageView)convertView.findViewById(R.id.seleced_state_imageview);
        }

    }

    static class textMsgViewHolder extends msgBaseViewHolder{

        LinearLayout im_plain_sender_layout;
        TextView text_chat_my_msg;

        LinearLayout im_plain_reveive_layout;
        TextView text_chat_buddy_msg;
        TextView receiver_nickname;//群昵称,只对群有用

        textMsgViewHolder(View convertView){
            super(convertView);
            content_body = convertView.findViewById(R.id.im_plain_layout);
            im_plain_sender_layout = (LinearLayout)convertView.findViewById(R.id.im_plain_sender_layout);
            text_chat_my_msg = (TextView)convertView.findViewById(R.id.text_chat_my_msg);

            im_plain_reveive_layout = (LinearLayout)convertView.findViewById(R.id.im_plain_receive_layout);
            text_chat_buddy_msg = (TextView)convertView.findViewById(R.id.text_chat_buddy_msg);
            receiver_nickname = (TextView)convertView.findViewById(R.id.receiver_nickname);
            convertView.setTag(this);
        }
    }

    static class ImageMsgViewHolder extends msgBaseViewHolder{

        LinearLayout im_image_sender_layout;
        ImageView img_chat_my_msg;

        LinearLayout im_plain_reveive_layout;
        ImageView img_chat_buddy_msg;
        TextView receiver_nickname;

        ImageMsgViewHolder(View convertView){
            super(convertView);
            content_body = convertView.findViewById(R.id.im_image_layout);
            im_image_sender_layout = (LinearLayout)convertView.findViewById(R.id.im_image_sender_layout);
            img_chat_my_msg = (ImageView)convertView.findViewById(R.id.img_chat_my_msg);
            im_plain_reveive_layout = (LinearLayout)convertView.findViewById(R.id.im_image_receive_layout);
            img_chat_buddy_msg = (ImageView)convertView.findViewById(R.id.img_chat_buddy_msg);
            receiver_nickname = (TextView)convertView.findViewById(R.id.receiver_nickname);
            convertView.setTag(this);
        }
    }

    static class VoiceMsgViewHolder extends msgBaseViewHolder{

        LinearLayout im_voice_sender_layout;
        TextView voice_msg_my_text;
        LinearLayout voice_msg_my_layout;
        ImageView voice_msg_my_img;

        LinearLayout im_voice_reveive_layout;
        TextView voice_msg_buddy_text;
        LinearLayout voice_msg_buddy_layout;
        ImageView voice_msg_buddy_img;
        ImageView voice_msg_read_state;
        TextView receiver_nickname;

        VoiceMsgViewHolder(View convertView){
            super(convertView);
            content_body = convertView.findViewById(R.id.im_voice_layout);
            im_voice_sender_layout = (LinearLayout)convertView.findViewById(R.id.im_voice_sender_layout);
            voice_msg_my_text = (TextView)convertView.findViewById(R.id.voice_msg_my_text);
            voice_msg_my_layout = (LinearLayout)convertView.findViewById(R.id.voice_msg_my_layout);
            this.voice_msg_my_img = (ImageView)convertView.findViewById(R.id.voice_msg_my_img);

            im_voice_reveive_layout = (LinearLayout)convertView.findViewById(R.id.im_voice_reveive_layout);
            voice_msg_buddy_text = (TextView)convertView.findViewById(R.id.voice_msg_buddy_text);
            voice_msg_buddy_layout = (LinearLayout)convertView.findViewById(R.id.voice_msg_buddy_layout);
            voice_msg_buddy_img = (ImageView)convertView.findViewById(R.id.voice_msg_buddy_img);
            voice_msg_read_state = (ImageView)convertView.findViewById(R.id.voice_msg_read_state);
            receiver_nickname = (TextView)convertView.findViewById(R.id.receiver_nickname);

            convertView.setTag(this);
        }
    }

    static class VideoMsgViewHolder extends msgBaseViewHolder{
        LinearLayout im_video_sender_layout;
        FrameLayout video_capture_my_layout;
        ImageView videoView_my_preview;
        Button button_play_my;

        LinearLayout im_video_reveive_layout;
        FrameLayout video_capture_buddy_layout;
        ImageView videoView_buddy_preview;
        Button button_play_buddy;
        CustomRoundProgressBar roundProgressBar;
        TextView receiver_nickname;

//        VideoView videoView_buddy;
//        VideoView videoView_my;

        VideoMsgViewHolder(View convertView){
            super(convertView);
            content_body = convertView.findViewById(R.id.im_video_layout);
            im_video_sender_layout = (LinearLayout)convertView.findViewById(R.id.im_video_sender_layout);
            video_capture_my_layout = (FrameLayout) convertView.findViewById(R.id.video_capture_my_layout);
            videoView_my_preview = (ImageView)convertView.findViewById(R.id.videoView_my_preview);
            button_play_my = (Button) convertView.findViewById(R.id.button_play_my);

            im_video_reveive_layout = (LinearLayout)convertView.findViewById(R.id.im_video_reveive_layout);
            video_capture_buddy_layout = (FrameLayout) convertView.findViewById(R.id.video_capture_buddy_layout);
            videoView_buddy_preview = (ImageView)convertView.findViewById(R.id.videoView_buddy_preview);
            button_play_buddy = (Button) convertView.findViewById(R.id.button_play_buddy);
            roundProgressBar = (CustomRoundProgressBar)convertView.findViewById(R.id.roundProgressBar);
            receiver_nickname = (TextView)convertView.findViewById(R.id.receiver_nickname);
            convertView.setTag(this);
        }
    }

    static class SystemMsgViewHolder extends msgDateViewHolder{
        TextView system_msg_content;

        SystemMsgViewHolder(View convertView){
            super(convertView);
            system_msg_content = (TextView)convertView.findViewById(R.id.system_msg_content);
            convertView.setTag(this);
        }
    }

    public static class MessageTimeComparator implements Comparator<MessageEntity> {
        @Override
        public int compare(MessageEntity lhs, MessageEntity rhs) {
            if (lhs.getCreated() == rhs.getCreated()) {
                return (int)(lhs.getId() - rhs.getId());
            }
            return (int)(lhs.getCreated() - rhs.getCreated());
        }
    }

}

