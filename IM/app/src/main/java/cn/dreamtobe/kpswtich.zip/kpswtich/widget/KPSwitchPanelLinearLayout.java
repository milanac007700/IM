package cn.dreamtobe.kpswtich.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import cn.dreamtobe.kpswtich.IPanelConflictLayout;
import cn.dreamtobe.kpswtich.IPanelHeightTarget;
import cn.dreamtobe.kpswtich.handler.KPSwitchPanelLayoutHandler;

/**
 * The panel container linear layout.
 * Resolve the layout-conflict from switching the keyboard and the Panel.
 */
public class KPSwitchPanelLinearLayout extends LinearLayout implements IPanelHeightTarget, IPanelConflictLayout {

    private KPSwitchPanelLayoutHandler panelLayoutHandler;

    private void init(final AttributeSet attrs) {
        panelLayoutHandler = new KPSwitchPanelLayoutHandler(this, attrs);
    }

    public KPSwitchPanelLinearLayout(Context context) {
        super(context);
        init(null);
    }

    public KPSwitchPanelLinearLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(attrs);
    }

    public KPSwitchPanelLinearLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(attrs);
    }

    @Override
    public void setVisibility(int visibility) {
        if(panelLayoutHandler.filterSetVisibility(visibility)) {
            return;
        }

        super.setVisibility(visibility);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        final int[] processOnMeasureWHSpec = panelLayoutHandler.processOnMeasure(widthMeasureSpec, heightMeasureSpec);
        super.onMeasure(processOnMeasureWHSpec[0], processOnMeasureWHSpec[1]);
    }

    @Override
    public boolean isKeyboradShowing() {
        return panelLayoutHandler.isKeyboradShowing();
    }

    @Override
    public boolean isVisible() {
        return panelLayoutHandler.isVisible();
    }

    @Override
    public void handleShow() {
        super.setVisibility(View.VISIBLE);
    }

    @Override
    public void handleHide() {
        panelLayoutHandler.handleHide();
    }

    @Override
    public void setIgnoreRecommendHeight(boolean isIgnoreRecommendHeight) {
        panelLayoutHandler.setIgnoreRecommendHeight(isIgnoreRecommendHeight);
    }

    @Override
    public void refreshHeight(int panelHeight) {
        panelLayoutHandler.resetToRecommendPanelHeight(panelHeight);
    }

    @Override
    public void onKeyboradShowing(boolean showing) {
        panelLayoutHandler.setmIsKeyboardShowing(showing);
    }
}
